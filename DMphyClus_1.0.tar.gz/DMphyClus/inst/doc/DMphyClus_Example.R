## ------------------------------------------------------------------------
library(DMphyClus)

data("seqsToCluster", package = "DMphyClus")
seqsToClusterChar <- as.character(ape::as.matrix.DNAbin(seqsToCluster))
seqsToCluster

## ------------------------------------------------------------------------
## Let's propose a random phylogeny as a starting state.
set.seed(10)
numSeqs <- nrow(seqsToClusterChar)
startingPhylo <- ape::rtree(numSeqs)
startingPhylo$tip.label <- rownames(seqsToClusterChar)[sample(1:numSeqs, size = numSeqs)]
startingPhylo

## ---- fig.width= 7, fig.height=7-----------------------------------------
rootChildren <- phangorn::Children(x = startingPhylo, node = ape::Ntip(startingPhylo)+1)
descendantsClades <- phangorn::Descendants(x = startingPhylo, node = rootChildren)

# Creating the clusInd vector

clusIndList <- mapply(seq_along(descendantsClades), descendantsClades, FUN = function(x,y) {
  clusVec <- rep(x, length(y))
  names(clusVec) <- startingPhylo$tip.label[y]
  clusVec
}, SIMPLIFY = FALSE)

clusIndStart <- do.call("c", clusIndList)
ape::plot.phylo(startingPhylo, tip.color = c("red", "blue")[clusIndStart])

## ------------------------------------------------------------------------
numCats <- 3 ## No. of rate variation categories (usually between 3 and 5)
gammaShapePosada2001 <- 0.7589 ## Based on Posada et al. 2001: the shape parameter of the discrete gamma distribution.
data("QmatrixPosada2001", package = "DMphyClus") ## The nucleotide substitution rate matrix
limProbsPosada2001 <- c(a = 0.39, t = 0.22, c = 0.17, g = 0.22) ## Based on Posada et al. 2001: the chain's limiting probabilities.

meanBetweenLength <- 0.03
meanBetweenVec <- seq(from = meanBetweenLength*0.5, to = meanBetweenLength*1.5, length.out = 10) ## A range of possible mean branch lengths in the supporting phylogeny.

## Getting transition matrices between clusters (1000 is not enough replicates, I would recommend 1e5)
numReplicates <- 1000
set.seed(20)
betweenClusTransProbs <- lapply(meanBetweenVec, FUN = function(x) {
 lNormMu <- log(x) - 0.3
 lNormSigma <- sqrt((log(x)-lNormMu)*2)
 outputTransMatList(QmatScaled = QmatrixPosada2001, numGammaCat = numCats,
                   gammaShape = gammaShapePosada2001, numReplicates = numReplicates,
                     distRanFun = rlnorm, meanlog = lNormMu, sdlog = lNormSigma)
}) ## Depending on the value of numReplicates, this can take several minutes...
betweenClusTransProbs[[1]]

## ------------------------------------------------------------------------
data("betweenClusTransProbs", package = "DMphyClus")
data("withinClusTransProbs", package = "DMphyClus")

## ------------------------------------------------------------------------
alphaVal <- 100 
numIters <- 100
numLikThreads <- 2
numMovesNNIbetween <- 1
numMovesNNIwithin <- 1
limProbs <- limProbsPosada2001
clusPhyloUpdateProp <- 1
shapeForAlpha <- 1000
scaleForAlpha <- 0.1
shiftForAlpha <- 10
poisRateNumClus <- 2
numSplitMergeMoves <- 3
startingValues <- list(phylogeny = startingPhylo, clusInd = clusIndStart, alpha = alphaVal)

## ---- message=FALSE, results = "hide"------------------------------------
set.seed(10)
DMphyClusOut <- DMphyClusChain(numIters = numIters, numLikThreads = numLikThreads, numMovesNNIbetween = numMovesNNIbetween, numMovesNNIwithin = numMovesNNIwithin,        alignment = seqsToClusterChar, startingValues = startingValues, limProbs = limProbsPosada2001, clusPhyloUpdateProp = clusPhyloUpdateProp, numSplitMergeMoves = numSplitMergeMoves, shapeForAlpha = shapeForAlpha, scaleForAlpha = scaleForAlpha, shiftForAlpha = shiftForAlpha, poisRateNumClus = poisRateNumClus, betweenClusTransMatList = betweenClusTransProbs, withinClusTransMatList = withinClusTransProbs)

## ------------------------------------------------------------------------
DMphyClusOut$MAPestimate

